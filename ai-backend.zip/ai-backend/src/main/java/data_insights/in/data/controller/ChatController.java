package data_insights.in.data.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import data_insights.in.data.payload.CricketResponse;
import data_insights.in.data.service.ChatService;
import lombok.SneakyThrows;
import org.springframework.ai.chat.model.StreamingChatModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/api/v1/chat")
@CrossOrigin("*")
public class ChatController {

    private final ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @GetMapping
    @CrossOrigin("*")
    public ResponseEntity<String> generateResponse(
            @RequestParam(value = "inputText", required = true) String inputText
    ) {
        String responseText = chatService.generateResponse(inputText);
        return ResponseEntity.ok(responseText);
    }

    @GetMapping("/stream")
    @CrossOrigin("*")
    public Flux<String> streamResponse(
            @RequestParam(value = "inputText", required = true) String inputText
    ) {
        return chatService.streamResponse(inputText);
    }

    @SneakyThrows
    @GetMapping("/cricket")
    @CrossOrigin("*")
    public ResponseEntity<CricketResponse> getCricketResponse(
            @RequestParam(value = "inputText", required = true) String inputText
    ) throws JsonProcessingException {
        return ResponseEntity.ok(chatService.generateCricketResponse(inputText));
    }

    @GetMapping("/image")
    @CrossOrigin("*")
    public ResponseEntity<List<String>> generateImages  (
            @RequestParam(value = "description") String imgDesc,
            @RequestParam(value ="numberOfImage", required = false, defaultValue = "3") int number
    ) throws IOException {
        try {
            return ResponseEntity.ok(chatService.generateImage(imgDesc,number))    ;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
