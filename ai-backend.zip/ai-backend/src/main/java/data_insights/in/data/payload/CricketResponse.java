package data_insights.in.data.payload;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class CricketResponse {

    private String content;

}
