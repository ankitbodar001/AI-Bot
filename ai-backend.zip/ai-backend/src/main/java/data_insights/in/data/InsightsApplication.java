package data_insights.in.data;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsightsApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(InsightsApplication.class, args);
	}

	@Override
	public void run(String... arg) throws Exception{

	}
}
