package data_insights.in.data.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import data_insights.in.data.payload.CricketResponse;
import groovy.lang.GString;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.StreamingChatModel;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.image.ImageModel;
import org.springframework.ai.image.ImageOptionsBuilder;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.image.ImageResponse;
import org.springframework.ai.openai.OpenAiImageModel;
import org.springframework.ai.openai.OpenAiImageOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ChatService {

    private final ChatModel chatModel;
    private final ImageModel imageModel;

    public ChatService(ChatModel chatModel, ImageModel imageModel) {
        this.chatModel = chatModel;
        this.imageModel = imageModel;
    }

    private ImageResponse imageResponse;

    private StreamingChatModel streamingChatModel;

    public String generateResponse(String inputText) {

        return chatModel.call(inputText);
    }
    public Flux<String> streamResponse(String inputText) {
        return chatModel.stream(inputText);
    }
    public CricketResponse generateCricketResponse(String inputText) throws IOException {

        String template = this.loadPromptTemplate("prompts/cricket_bot.txt");
        String promptString = this.putValueInPromptTemplate(template, Map.of(
                "inputText",inputText
        ));

        ChatResponse cricketResponse = chatModel.call(new Prompt(promptString));
        String responseString = cricketResponse.getResult().getOutput().getText().trim();

        // Clean up common LLM formatting issues
        String jsonCleaned = responseString
                .replaceAll("(?s).*?\\{", "{")     // keep from first {
                .replaceAll("}[^}]*$", "}")       // keep until last }
                .replaceAll("```json", "")
                .replaceAll("```", "")
                .replaceAll("`", "")
                .trim();

        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(jsonCleaned, CricketResponse.class);
    }
    public List<String> generateImage(String imgDesc, int number) throws IOException {

        String template = this.loadPromptTemplate("prompts/image.txt");
        String promptString = this.putValueInPromptTemplate(template, Map.of(
                "description",imgDesc
        ));

        ImageResponse imageResponse = imageModel.call(new ImagePrompt(promptString,
                OpenAiImageOptions.builder()
                        .withModel("dall-e-3")
                        .N(1)
                        .withWidth(1024)
                        .withHeight(1024)
                        .withQuality("standard")
                        .build()));
        List<String> imgUrls = imageResponse.getResults().stream().map(generation->generation.getOutput().getUrl()).toList();
        return imgUrls;
    }
    public String loadPromptTemplate(String fileName) throws IOException {
        Path filePath = new ClassPathResource(fileName).getFile().toPath();
        return Files.readString(filePath);
    }
    public String putValueInPromptTemplate(String template, Map<String, String> value) {
        for (Map.Entry<String, String> entry : value.entrySet()) {
            template = template.replace("(" + entry.getKey()+")", entry.getValue());
        }
        return template;
    }
}
