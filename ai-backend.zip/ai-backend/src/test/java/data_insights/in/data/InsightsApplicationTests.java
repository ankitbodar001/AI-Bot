package data_insights.in.data;

import com.fasterxml.jackson.core.JsonProcessingException;
import data_insights.in.data.payload.CricketResponse;
import data_insights.in.data.service.ChatService;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.util.Map;


@SpringBootTest
class InsightsApplicationTests {

	@Autowired
	private ChatService chatService;
//
//	@SneakyThrows
//    @Test
//    void contextLoads() throws JsonProcessingException {
//		CricketResponse cricketResponse= chatService.generateCricketResponse("Who is Sachin?");
//		System.out.println("Response: " + cricketResponse);
//	}
@SneakyThrows
	@Test
	void contextLoads() throws IOException {
		String s = chatService.loadPromptTemplate("prompts/cricket_bot.txt");
		String prompt = chatService.putValueInPromptTemplate(s, Map.of("inputText", "Who is Sachin?"));
		System.out.println(prompt);
	}

}
